Rails.application.routes.draw do
	root 'home#checkr'
end
