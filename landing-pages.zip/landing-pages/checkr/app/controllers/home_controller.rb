class HomeController < ApplicationController
  def checkr
    #
  end
end
