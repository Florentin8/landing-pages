Rails.application.routes.draw do
	root 'home#flynn'
end
