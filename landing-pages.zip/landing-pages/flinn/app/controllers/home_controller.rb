class HomeController < ApplicationController
  def flynn
    #
  end
end
